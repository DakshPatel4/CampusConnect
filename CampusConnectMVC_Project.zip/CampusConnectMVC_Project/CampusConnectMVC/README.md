# CampusConnect MVC — Student Record Management

A mini-project for **Web Technologies with .NET** using ASP.NET Core MVC, Entity Framework Core, and MySQL. It demonstrates MVC architecture, database connectivity, CRUD operations, form handling, model validation, state messages using TempData, searching/filtering, and a responsive interface.

## Features
- Add, view, edit, and delete student records
- Search by name, enrollment number, or email
- Filter by department and student status
- Server-side validation and unique enrollment number check
- MySQL persistence through Entity Framework Core
- Responsive dashboard-style interface
- Success feedback through TempData

## Requirements
- .NET 8 SDK
- MySQL Server 8.x (or compatible)
- Visual Studio 2022 or VS Code

## Setup
1. Extract the ZIP and open the `CampusConnectMVC` folder in Visual Studio or VS Code.
2. Create a MySQL database. You can run:
   ```sql
   CREATE DATABASE campusconnect_db;
   ```
3. Open `appsettings.json` and replace `YOUR_MYSQL_PASSWORD` with your local MySQL password. If your MySQL user is not `root`, update the username too.
4. In a terminal inside the project folder, restore packages:
   ```bash
   dotnet restore
   ```
5. Create the database tables using EF Core:
   ```bash
   dotnet tool install --global dotnet-ef
   dotnet ef migrations add InitialCreate
   dotnet ef database update
   ```
   If `dotnet-ef` is already installed, skip the install command. If your system has a different SDK, ensure the .NET 8 SDK is installed.
6. Run:
   ```bash
   dotnet run
   ```
7. Open the localhost URL printed in the terminal.

## Database
The `Students` table is created by EF Core. `EnrollmentNumber` has a unique index. The application does not include real student data; enter sample records for your demonstration.

## Project structure
```text
CampusConnectMVC/
├── Controllers/
│   ├── HomeController.cs
│   └── StudentsController.cs
├── Data/
│   └── ApplicationDbContext.cs
├── Models/
│   └── Student.cs
├── Views/
│   ├── Shared/
│   └── Students/
├── wwwroot/css/site.css
├── appsettings.json
├── Program.cs
└── CampusConnectMVC.csproj
```

## Demo flow
1. Add 3–5 sample students in different departments and semesters.
2. Demonstrate required-field and invalid-email validation.
3. Show search and filters.
4. Open a student record, edit it, and verify the change.
5. Delete a sample record and show the confirmation screen.

## Notes
- Keep local database passwords out of public GitHub repositories. For submission, replace the password with a placeholder and mention configuration in this README.
- The validation helper scripts use CDN links, so client-side validation needs internet access. Server-side validation remains active.
- This is a college mini-project starter. Test it on your machine and understand each controller/model/view before presenting it.
