using CampusConnectMVC.Models;
using Microsoft.EntityFrameworkCore;

namespace CampusConnectMVC.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Student> Students => Set<Student>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<Student>()
            .HasIndex(s => s.EnrollmentNumber)
            .IsUnique();
    }
}
