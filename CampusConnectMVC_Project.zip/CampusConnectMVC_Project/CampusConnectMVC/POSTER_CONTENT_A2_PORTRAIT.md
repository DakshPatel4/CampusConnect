# CampusConnect — Student Record Management System
## Web Technologies with .NET | Mini Project

### Problem Statement
Student records are often maintained across separate spreadsheets or paper files, making updates, searching, and record consistency time-consuming. CampusConnect provides a central web interface for managing student records.

### Objectives
- Build a real-world student record management application.
- Apply the ASP.NET Core MVC architecture.
- Connect to MySQL using Entity Framework Core.
- Implement complete CRUD operations.
- Validate forms and prevent duplicate enrollment numbers.
- Provide search, filters, and a responsive interface.

### Technology Stack
- Front end: HTML5, CSS3, Razor Views
- Application: C#, ASP.NET Core MVC (.NET 8)
- ORM: Entity Framework Core
- Database: MySQL
- State feedback: TempData
- Validation: Data Annotations + server-side ModelState

### System Architecture
**Browser → Razor View (UI) → StudentsController → ApplicationDbContext / EF Core → MySQL Database**

### Implemented Modules
1. Student Directory — list, search, department/status filters
2. Add Student — validated form and duplicate enrollment check
3. Student Details — individual record view
4. Edit Student — update existing details
5. Delete Student — confirmation before deletion
6. Feedback — success messages after database operations

### Database Design: Student
| Field | Type / Rule |
|---|---|
| Id | Integer, primary key |
| EnrollmentNumber | Required, unique |
| FullName | Required, 2–60 characters |
| Email | Required, valid email |
| Department | Required |
| Semester | Integer, 1–8 |
| AdmissionDate | Date |
| Status | Active / Graduated / On Leave |

### Application Screenshots
Add genuine screenshots from your running application:
1. Student Directory and filters
2. Add Student form with validation
3. Student Details
4. Edit Student form
5. Delete confirmation

### Results
CampusConnect demonstrates an end-to-end MVC web application with MySQL persistence, validated forms, and CRUD functionality. Search and filters help users locate records quickly.

### Conclusion
The project applies core ASP.NET Core MVC concepts to a practical campus administration problem. Future enhancements could include login/roles, attendance tracking, CSV export, pagination, and audit history.

**Prepared for:** Web Technologies with .NET — Mini Project and Poster Presentation  
**Poster requirement:** A2 size, portrait orientation, PDF soft copy
