using System.ComponentModel.DataAnnotations;

namespace CampusConnectMVC.Models;

public class Student
{
    public int Id { get; set; }

    [Required, StringLength(20, MinimumLength = 3)]
    [Display(Name = "Enrollment Number")]
    public string EnrollmentNumber { get; set; } = string.Empty;

    [Required, StringLength(60, MinimumLength = 2)]
    [Display(Name = "Full Name")]
    public string FullName { get; set; } = string.Empty;

    [Required, EmailAddress, StringLength(120)]
    public string Email { get; set; } = string.Empty;

    [Required, StringLength(40)]
    public string Department { get; set; } = string.Empty;

    [Required, Range(1, 8)]
    public int Semester { get; set; }

    [Required]
    [Display(Name = "Admission Date")]
    [DataType(DataType.Date)]
    public DateTime AdmissionDate { get; set; } = DateTime.Today;

    [Required]
    public StudentStatus Status { get; set; } = StudentStatus.Active;
}

public enum StudentStatus
{
    Active,
    Graduated,
    OnLeave
}
