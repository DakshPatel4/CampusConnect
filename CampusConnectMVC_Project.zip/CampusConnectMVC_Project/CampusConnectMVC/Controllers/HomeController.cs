using Microsoft.AspNetCore.Mvc;

namespace CampusConnectMVC.Controllers;

public class HomeController : Controller
{
    public IActionResult Index() => RedirectToAction("Index", "Students");
    public IActionResult Error() => View();
}
