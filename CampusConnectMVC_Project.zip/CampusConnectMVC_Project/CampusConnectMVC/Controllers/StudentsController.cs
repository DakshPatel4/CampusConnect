using CampusConnectMVC.Data;
using CampusConnectMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusConnectMVC.Controllers;

public class StudentsController : Controller
{
    private readonly ApplicationDbContext _context;

    public StudentsController(ApplicationDbContext context) => _context = context;

    public async Task<IActionResult> Index(string? search, string? department, StudentStatus? status)
    {
        var query = _context.Students.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            search = search.Trim();
            query = query.Where(s => s.FullName.Contains(search)
                || s.EnrollmentNumber.Contains(search)
                || s.Email.Contains(search));
        }

        if (!string.IsNullOrWhiteSpace(department))
            query = query.Where(s => s.Department == department);

        if (status.HasValue)
            query = query.Where(s => s.Status == status.Value);

        ViewBag.Search = search;
        ViewBag.Department = department;
        ViewBag.Status = status;
        ViewBag.Departments = await _context.Students
            .Select(s => s.Department).Distinct().OrderBy(d => d).ToListAsync();

        return View(await query.OrderBy(s => s.FullName).ToListAsync());
    }

    public IActionResult Create() => View(new Student { AdmissionDate = DateTime.Today });

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Student student)
    {
        if (await _context.Students.AnyAsync(s => s.EnrollmentNumber == student.EnrollmentNumber))
            ModelState.AddModelError(nameof(student.EnrollmentNumber), "This enrollment number already exists.");

        if (!ModelState.IsValid) return View(student);

        _context.Students.Add(student);
        await _context.SaveChangesAsync();
        TempData["Success"] = $"Student {student.FullName} was added successfully.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Details(int? id)
    {
        if (id is null) return NotFound();
        var student = await _context.Students.AsNoTracking().FirstOrDefaultAsync(s => s.Id == id);
        return student is null ? NotFound() : View(student);
    }

    public async Task<IActionResult> Edit(int? id)
    {
        if (id is null) return NotFound();
        var student = await _context.Students.FindAsync(id);
        return student is null ? NotFound() : View(student);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Student student)
    {
        if (id != student.Id) return NotFound();

        if (await _context.Students.AnyAsync(s =>
            s.EnrollmentNumber == student.EnrollmentNumber && s.Id != student.Id))
            ModelState.AddModelError(nameof(student.EnrollmentNumber), "This enrollment number is already assigned to another student.");

        if (!ModelState.IsValid) return View(student);

        try
        {
            _context.Update(student);
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!await _context.Students.AnyAsync(s => s.Id == id)) return NotFound();
            throw;
        }

        TempData["Success"] = $"Student {student.FullName} was updated successfully.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int? id)
    {
        if (id is null) return NotFound();
        var student = await _context.Students.AsNoTracking().FirstOrDefaultAsync(s => s.Id == id);
        return student is null ? NotFound() : View(student);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var student = await _context.Students.FindAsync(id);
        if (student is not null)
        {
            _context.Students.Remove(student);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Student {student.FullName} was deleted.";
        }
        return RedirectToAction(nameof(Index));
    }
}
